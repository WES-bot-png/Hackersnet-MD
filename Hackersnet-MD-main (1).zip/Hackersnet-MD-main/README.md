# Hackersnet-MD
A simple WhatsApp bot to manage groups
